import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {

        JFrame frame = new JFrame();
        //设置
        frame.setTitle("hello,world!");   //标题
        frame.setSize(800,500);   //大小

        //将容器添加到窗体上
        frame.add(new panel());
        //设置是否可见
        frame.setVisible(true);

    }
}

//创建容器，将容器添加到窗体上
// JLayeredPane 是JAVA提供的一个容器类
class panel extends JLayeredPane{
    //进行初始化
    public panel() {
    //添加文字
        JLabel label1 = new JLabel();
        label1.setText("快来学习计算机");
        // 设置字体
        label1.setFont(new Font("宋体",Font.BOLD,15));

        // 设置字体宽和高
        //X,Y表示字体栏的位置
        //width,height表示字体栏大小
        label1.setBounds(20,10,200,200);
        // 添加到容器上
        add(label1);
    // 添加按钮
        //new一个按钮
        JButton button1 = new JButton();
        //添加按钮的文字说明
        button1.setText("确定");
        button1.setBounds(100,200,80,30);
        add(button1);


    }

}

