import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Menu {
    public static void main(String[] args){
        JMenu menu = new JMenu("菜单");
        JFrame f = new JFrame("一级菜单");
        JFrame f1 = new JFrame("快来学JAVA");
        //设置流式布局
        //f.setLayout(new FlowLayout());
        //创建一个菜单栏
        JMenuBar bar = new JMenuBar();
        //创建一个菜单选项
        JMenuItem item1 = new JMenuItem("退出系统");
        JMenuItem item2 = new JMenuItem("加载对话框");


        //将菜单项加入到菜单，将菜单加入到菜单栏，将菜单栏加入窗口
        f.setJMenuBar(bar);
        bar.add(menu);
        menu.add(item1);
        menu.add(item2);

        //菜单项的内容
        item1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        item2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                f1.setVisible(true);
            }
        });

        //关闭窗口
        f.addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);

            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });


        f.setVisible(true);


    }
}
